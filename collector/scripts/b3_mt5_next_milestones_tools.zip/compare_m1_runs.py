from __future__ import annotations

import argparse
import re
from pathlib import Path

import polars as pl

FIELDS = ["open", "high", "low", "close", "tick_volume", "spread", "real_volume"]


def symbol_from_path(path: Path) -> str:
    match = re.match(r"bars_m1_(.+)\.parquet$", path.name)
    if not match:
        raise ValueError(path.name)
    return match.group(1)


def compare_file(old_path: Path, new_path: Path) -> tuple[dict, pl.DataFrame]:
    symbol = symbol_from_path(old_path)
    old = pl.read_parquet(old_path).select(["time", *FIELDS]).sort("time")
    new = pl.read_parquet(new_path).select(["time", *FIELDS]).sort("time")

    joined = old.join(new, on="time", how="full", suffix="_new", coalesce=True)
    old_exists = pl.any_horizontal([pl.col(f).is_not_null() for f in FIELDS])
    new_exists = pl.any_horizontal([pl.col(f"{f}_new").is_not_null() for f in FIELDS])

    changes = []
    change_exprs = []
    for field in FIELDS:
        expr = (
            pl.col(field).is_null() != pl.col(f"{field}_new").is_null()
        ) | (
            pl.col(field).is_not_null()
            & pl.col(f"{field}_new").is_not_null()
            & (pl.col(field) != pl.col(f"{field}_new"))
        )
        change_exprs.append(expr.alias(f"changed_{field}"))

    joined = joined.with_columns(
        old_exists.alias("old_exists"),
        new_exists.alias("new_exists"),
        *change_exprs,
    ).with_columns(
        pl.any_horizontal([pl.col(f"changed_{f}") for f in FIELDS]).alias("any_changed"),
        pl.from_epoch("time", time_unit="s").alias("ts_server_wall"),
        pl.lit(symbol).alias("symbol"),
    )

    detail = joined.filter(
        (~pl.col("old_exists")) | (~pl.col("new_exists")) | pl.col("any_changed")
    )

    summary = {
        "symbol": symbol,
        "old_rows": old.height,
        "new_rows": new.height,
        "added_timestamps": int(joined.filter(~pl.col("old_exists") & pl.col("new_exists")).height),
        "removed_timestamps": int(joined.filter(pl.col("old_exists") & ~pl.col("new_exists")).height),
        "changed_timestamps": int(joined.filter(pl.col("old_exists") & pl.col("new_exists") & pl.col("any_changed")).height),
    }
    for field in FIELDS:
        summary[f"changed_{field}"] = int(
            joined.filter(pl.col("old_exists") & pl.col("new_exists") & pl.col(f"changed_{field}")).height
        )
    return summary, detail


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Compare two immutable MT5 M1 run directories.")
    parser.add_argument("--old", type=Path, required=True)
    parser.add_argument("--new", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    args.out.mkdir(parents=True, exist_ok=False)

    old_files = {symbol_from_path(p): p for p in args.old.glob("bars_m1_*.parquet")}
    new_files = {symbol_from_path(p): p for p in args.new.glob("bars_m1_*.parquet")}
    common = sorted(old_files.keys() & new_files.keys())
    if not common:
        raise RuntimeError("No common bars_m1_*.parquet files found")

    summaries = []
    details = []
    for symbol in common:
        summary, detail = compare_file(old_files[symbol], new_files[symbol])
        summaries.append(summary)
        if detail.height:
            details.append(detail)

    summary_frame = pl.DataFrame(summaries)
    summary_frame.write_csv(args.out / "comparison_summary.csv")
    summary_frame.write_parquet(args.out / "comparison_summary.parquet", compression="zstd")
    if details:
        pl.concat(details, how="diagonal_relaxed").write_parquet(
            args.out / "comparison_details.parquet", compression="zstd"
        )

    print(summary_frame)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
