from __future__ import annotations

import argparse
import re
from pathlib import Path

import polars as pl


def hhmm_to_minute(value: str) -> int:
    match = re.fullmatch(r"(\d{1,2}):(\d{2})", value)
    if not match:
        raise argparse.ArgumentTypeError("Expected HH:MM")
    hour, minute = map(int, match.groups())
    if not (0 <= hour <= 23 and 0 <= minute <= 59):
        raise argparse.ArgumentTypeError("Invalid HH:MM")
    return hour * 60 + minute


def symbol_from_path(path: Path) -> str:
    match = re.match(r"bars_m1_(.+)\.parquet$", path.name)
    if not match:
        raise ValueError(path.name)
    return match.group(1)


def summarize_file(
    path: Path,
    session_start: int,
    session_end: int,
    exclude_last_n_dates: int,
) -> dict:
    symbol = symbol_from_path(path)
    frame = pl.read_parquet(path).select(
        "time", "open", "high", "low", "close", "tick_volume", "real_volume"
    )
    wall = pl.from_epoch("time", time_unit="s")
    frame = frame.with_columns(
        wall.dt.date().alias("date"),
        (wall.dt.hour().cast(pl.Int32) * 60 + wall.dt.minute().cast(pl.Int32)).alias("minute_of_day"),
    )

    dates = frame.select(pl.col("date").unique().sort()).to_series().to_list()
    if exclude_last_n_dates > 0 and len(dates) > exclude_last_n_dates:
        keep_through = dates[-exclude_last_n_dates - 1]
        frame = frame.filter(pl.col("date") <= pl.lit(keep_through))

    frame = frame.filter(
        pl.col("minute_of_day").is_between(session_start, session_end, closed="both")
    )
    if frame.height == 0:
        return {"symbol": symbol, "error": "No bars in selected core session"}

    expected_minutes = session_end - session_start + 1
    daily = frame.group_by("date").agg(
        pl.len().alias("active_minutes"),
        pl.col("real_volume").sum().alias("daily_real_volume"),
        (pl.col("close") * pl.col("real_volume")).sum().alias("daily_notional_brl"),
        pl.col("tick_volume").sum().alias("daily_tick_volume"),
        (pl.col("high") == pl.col("low")).mean().alias("zero_range_share"),
    ).with_columns(
        (pl.col("active_minutes") / expected_minutes).alias("active_share")
    )

    summary = daily.select(
        pl.len().alias("days"),
        pl.col("date").min().alias("first_date"),
        pl.col("date").max().alias("last_date"),
        pl.col("active_share").median().alias("median_active_share"),
        pl.col("active_share").quantile(0.10, interpolation="nearest").alias("p10_active_share"),
        pl.col("daily_real_volume").median().alias("median_daily_real_volume"),
        pl.col("daily_notional_brl").median().alias("median_daily_notional_brl"),
        pl.col("daily_tick_volume").median().alias("median_daily_tick_volume"),
        pl.col("zero_range_share").median().alias("median_zero_range_share"),
    ).to_dicts()[0]
    return {"symbol": symbol, **summary, "error": None}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Rank cash equities/ETFs from MT5 M1 Parquet files."
    )
    parser.add_argument("--input-dir", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--session-start", type=hhmm_to_minute, default=615, help="Default 10:15")
    parser.add_argument("--session-end", type=hhmm_to_minute, default=1005, help="Default 16:45")
    parser.add_argument("--exclude-last-n-dates", type=int, default=2)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    files = sorted(args.input_dir.glob("bars_m1_*.parquet"))
    if not files:
        raise RuntimeError("No bars_m1_*.parquet files found")
    records = [
        summarize_file(
            path,
            session_start=args.session_start,
            session_end=args.session_end,
            exclude_last_n_dates=args.exclude_last_n_dates,
        )
        for path in files
    ]
    frame = pl.DataFrame(records, strict=False)
    valid = frame.filter(pl.col("error").is_null())
    invalid = frame.filter(pl.col("error").is_not_null())

    # Percentile ranks keep the score scale stable across candidate-pool sizes.
    valid = valid.with_columns(
        (pl.col("median_active_share").rank("average") / pl.len()).alias("median_active_share_rank"),
        (pl.col("p10_active_share").rank("average") / pl.len()).alias("p10_active_share_rank"),
        (pl.col("median_daily_notional_brl").log1p().rank("average") / pl.len()).alias("median_daily_notional_rank"),
        (pl.col("median_zero_range_share").rank("average", descending=True) / pl.len()).alias("low_zero_range_rank"),
    )

    # Rejoin original metrics, then calculate the score.
    metrics = frame.filter(pl.col("error").is_null())
    valid = metrics.join(valid.select(
        "symbol",
        "median_active_share_rank",
        "p10_active_share_rank",
        "median_daily_notional_rank",
        "low_zero_range_rank",
    ), on="symbol").with_columns(
        (
            0.35 * pl.col("median_active_share_rank")
            + 0.20 * pl.col("p10_active_share_rank")
            + 0.35 * pl.col("median_daily_notional_rank")
            + 0.10 * pl.col("low_zero_range_rank")
        ).alias("liquidity_score")
    ).sort("liquidity_score", descending=True)

    args.out.mkdir(parents=True, exist_ok=False)
    valid.write_csv(args.out / "cash_m1_liquidity_ranking.csv")
    valid.write_parquet(args.out / "cash_m1_liquidity_ranking.parquet", compression="zstd")
    if invalid.height:
        invalid.write_csv(args.out / "cash_m1_liquidity_errors.csv")
    print(valid.select(
        "symbol", "liquidity_score", "median_active_share", "p10_active_share", "median_daily_notional_brl"
    ).head(60))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
